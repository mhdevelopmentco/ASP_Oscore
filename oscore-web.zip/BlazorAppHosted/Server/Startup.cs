using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System.Net.Http.Headers;
using BlazorAppHosted.Client;
using BlazorAppHosted.Client.Services;
using BlazorAppHosted.Server.Services;
using BlazorAppHosted.Server.Services.MailchimpService;
using BlazorAppHosted.Server.Services.SlackService;
using Microsoft.AspNetCore.Components;
using Microsoft.Extensions.FileProviders;

namespace BlazorAppHosted.Server
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        // For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=398940
        public void ConfigureServices(IServiceCollection services)
        {

            services.AddControllersWithViews();
            services.AddRazorPages();
            services.AddHttpClient("mailchimp",
                client =>
                {
                    client.BaseAddress = new Uri("https://us19.api.mailchimp.com/3.0/");

                    var mailchimpApiKey = Configuration["MailchimpApiKey"];

                    client.DefaultRequestHeaders.Authorization =
                        AuthenticationHeaderValue.Parse(mailchimpApiKey);
                });

            services.AddScoped<ISlackService, SlackService>();
            services.AddScoped<IMailchimpService, MailchimpService>();

            services.AddServerSideBlazor();

            // Server Side Blazor doesn't register HttpClient by default
            if (services.All(x => x.ServiceType != typeof(HttpClient)))
            {
                // Setup HttpClient for server side in a client side compatible fashion
                services.AddScoped<HttpClient>(s =>
                {
                    // Creating the URI helper needs to wait until the JS Runtime is initialized, so defer it.      
                    var uriHelper = s.GetRequiredService<NavigationManager>();
                    return new HttpClient
                    {
                        BaseAddress = new Uri(uriHelper.BaseUri)
                    };
                });
            }

            services.AddScoped<ISubmitContactRequestService, SubmitContactRequestService>();

            services.AddScoped<IPageTitleService, PageTitleService>();

            services.AddScoped<IContactPageContentService, ContactPageContentService>();


        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseWebAssemblyDebugging();
            }
            else
            {
                app.UseExceptionHandler("/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.UseHttpsRedirection();

            app.UseDefaultFiles(new DefaultFilesOptions() { DefaultFileNames = new List<string>() { "index.html" } });

            //app.UseBlazorFrameworkFiles();
            
            app.UseStaticFiles();

            app.UseRouting();

            //app.UseEndpoints(endpoints =>
            //{
            //    endpoints.MapControllers();
            //    endpoints.MapRazorPages();
            //});

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapRazorPages();
                endpoints.MapBlazorHub();
                endpoints.MapDefaultControllerRoute();
                endpoints.MapFallbackToFile("index.html");
            });


            app.Map("/contact", subApp =>
            {
                //subApp.UseBlazorFrameworkFiles();

                subApp.UseStaticFiles();

                subApp.UseRouting();

                subApp.UseEndpoints(endpoints =>
                {
                    endpoints.MapBlazorHub();

                    endpoints.MapFallbackToPage("/general");
                });
            });

            app.Map("/learn-more", subApp =>
            {
                //subApp.UseBlazorFrameworkFiles();
                
                subApp.UseStaticFiles();

                subApp.UseRouting();

                subApp.UseEndpoints(endpoints =>
                {
                    endpoints.MapBlazorHub();

                    endpoints.MapFallbackToPage("/learn-more.azure-cosmos-db");
                });
            });
        }
    }
}
