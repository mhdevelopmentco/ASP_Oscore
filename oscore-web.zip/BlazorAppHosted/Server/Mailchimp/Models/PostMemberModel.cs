﻿using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace BlazorAppHosted.Server.Mailchimp.Models
{
    public class PostMemberModel
    {
        [JsonPropertyName("email_address")]
        public string EmailAddress { get; set; }
        
        [JsonPropertyName("status")]
        public string Status { get; set; }

        [JsonPropertyName("merge_fields")]
        public Dictionary<string, object> MergeFields { get; set; }
    }
}
