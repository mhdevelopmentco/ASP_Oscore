﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Hosting;

namespace BlazorAppHosted.Server
{
    public class Program
    {
        public static void Main(string[] args)
        {
            CreateHostBuilder(args).Build().Run();
        }


        //TODO complete Azure Key Vault implementation
        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                //.ConfigureAppConfiguration((context, config) =>
                //{
                //    var keyVaultEndpoint =
                //        new Uri(Environment.GetEnvironmentVariable("OscoreWebKeyVaultConnectionString"));
                //    config.AddAzureKeyVault(
                //        keyVaultEndpoint,
                //        new DefaultAzureCredential());
                //})
                .ConfigureWebHostDefaults(webBuilder => { webBuilder.UseStartup<Startup>(); });
    }
}
