﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text.Json;
using System.Threading.Tasks;
using BlazorAppHosted.Server.Services;
using BlazorAppHosted.Server.Services.MailchimpService;
using BlazorAppHosted.Server.Services.SlackService;
using BlazorAppHosted.Shared;
using Microsoft.AspNetCore.Mvc;

namespace BlazorAppHosted.Server.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ContactsController : ControllerBase
    {
        private readonly ISlackService _slackService;
        private readonly IMailchimpService _mailchimpService;

        public ContactsController(ISlackService slackService, IMailchimpService mailchimpService)
        {
            _slackService = slackService;
            _mailchimpService = mailchimpService;
        }

        [HttpPost]
        public async Task<IActionResult> PostNewContact(ContactRequestModel contactRequestModel)
        {
            await _mailchimpService.Post(contactRequestModel);

            _slackService.Post(contactRequestModel);

            return Ok(contactRequestModel);
        }
    }
}