﻿using System;
using System.Linq;
using System.Net.Http;
using Microsoft.Extensions.Configuration;
using Slack.Webhooks;

namespace BlazorAppHosted.Server.Services.SlackService
{
    public class SlackService : ISlackService
    {
        private string AppSlackHook { get; }

        private readonly SlackClient _slackClient;

        public SlackService(IConfiguration configuration, IHttpClientFactory httpClientFactory)
        {
            var httpClient = httpClientFactory.CreateClient();

            AppSlackHook = configuration["MarketingSlackWebhookUrl"];

            _slackClient = new SlackClient(AppSlackHook, httpClient: httpClient);
        }

        public void PostMessage(string title, params string[] message)
        {
            var slackClient = _slackClient;

            slackClient.Post(new SlackMessage()
            {
                Text = title,
                Attachments = message.Select(x => new SlackAttachment()
                {
                    Text = $"{x}",
                    Color = "#36a64f"
                }).ToList()
            });
        }

        public void Post(SlackMessage slackMessage)
        {
            try
            {
                var rv = _slackClient.Post(slackMessage);

                Console.WriteLine(rv);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }
    }
}
