﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using BlazorAppHosted.Shared;
using Slack.Webhooks;
using Slack.Webhooks.Elements;

namespace BlazorAppHosted.Server.Services.SlackService
{
    public static class Extensions
    {
        public static void Post(this ISlackService slackService,
            ContactRequestModel contactRequestModel)
        {
            static TextObject Markdown(string text) => new TextObject(text) {Type = TextObject.TextType.Markdown};

            var message = new SlackMessage()
            {
                Text = "Contact request received from " + contactRequestModel.Email,

                // https://api.slack.com/tools/block-kit-builder
                Blocks = new List<Block>()
                {
                    new Slack.Webhooks.Blocks.Section()
                    {
                        Text = Markdown(
                            $":star: Contact request received from *<mailto:{contactRequestModel.Email}|{contactRequestModel.Name}>* ({contactRequestModel.Email})")
                    },
                    new Slack.Webhooks.Blocks.Section()
                    {
                        Fields = new List<TextObject>()
                        {
                            Markdown($"*Name*\n{contactRequestModel.Name}"),

                            Markdown($"*Email*\n{contactRequestModel.Email}")
                        },

                        Text = Markdown($"*Project*\n{contactRequestModel.Project}")
                    },
                    new Slack.Webhooks.Blocks.Section()
                    {
                        Text = Markdown(
                            $"*From Page*\n{contactRequestModel.ContactPageAddress}")
                    },
                    new Slack.Webhooks.Blocks.Section()
                    {
                        Text = Markdown(
                            $"*Data Collection Consent*\n{(contactRequestModel.DataCollectionConsent ? "Received" : "*NOT* received")}")
                    },
                }
            };

            slackService.Post(message);
        }

        public static void PostException(this ISlackService slackService, Exception exceptionOccured,
            object toSerialize)
        {
            var serialized = JsonSerializer.Serialize(toSerialize);

            // ReSharper disable once PossiblyMistakenUseOfParamsMethod
            slackService.PostException(exceptionOccured, serialized);
        }

        public static void PostException(this ISlackService slackService, Exception exceptionOccured,
            params string[] extraMessages)
        {
            var slackAttachments = new List<SlackAttachment>()
            {
                new SlackAttachment()
                {
                    Text = exceptionOccured.Message,
                    Color = "#36a64f"
                },
                new SlackAttachment()
                {
                    Text = exceptionOccured.StackTrace,
                    Color = "#36a64f"
                },
                new SlackAttachment()
                {
                    Text = exceptionOccured.ToString(),
                    Color = "#36a64f"
                }
            };

            slackAttachments.InsertRange(0, extraMessages.Select(x => new SlackAttachment()
            {
                Text = x,
                Color = "#36a64f"
            }));

            var slackMessage = new SlackMessage()
            {
                Text = "Exception occured",
                Attachments = slackAttachments
            };

            slackService.Post(slackMessage);

        }
    }
}