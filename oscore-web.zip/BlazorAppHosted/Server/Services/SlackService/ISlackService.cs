﻿using System;
using Slack.Webhooks;

namespace BlazorAppHosted.Server.Services.SlackService
{
    public interface ISlackService
    {
        void Post(SlackMessage slackMessage);
    }
}
