﻿using System;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;
using BlazorAppHosted.Server.Services.MailchimpService.Models;
using BlazorAppHosted.Server.Services.SlackService;

namespace BlazorAppHosted.Server.Services.MailchimpService
{
    public class MailchimpService : IMailchimpService
    {
        private readonly ISlackService _slackService;
        private readonly HttpClient _httpClient;

        public MailchimpService(IHttpClientFactory httpClientFactory, ISlackService slackService)
        {
            _slackService = slackService;
            _httpClient = httpClientFactory.CreateClient("mailchimp");
        }

        public async Task Post(PostMemberModel postMemberModel)
        {
            try
            {
                var response = await _httpClient.PostAsJsonAsync("lists/dc59e61f5e/members", postMemberModel);

                if (!response.IsSuccessStatusCode)
                {
                    var content = await response.Content.ReadAsStringAsync();
                    throw new Exception(content);
                }
            }
            catch (Exception ex)
            {
                _slackService.PostException(ex, postMemberModel);
                throw;
            }
        }
    }
}
