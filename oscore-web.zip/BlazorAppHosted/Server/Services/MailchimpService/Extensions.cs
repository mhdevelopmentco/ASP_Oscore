﻿using System.Collections.Generic;
using System.Threading.Tasks;
using BlazorAppHosted.Server.Services.MailchimpService.Models;
using BlazorAppHosted.Shared;

namespace BlazorAppHosted.Server.Services.MailchimpService
{
    public static class Extensions
    {
        public static async Task Post(this IMailchimpService mailchimpService,
            ContactRequestModel contactRequestModel)
        {
            const string dataConsentInterestId = "bf7c45524a";

            var postMemberModel = new PostMemberModel()
            {
                EmailAddress = contactRequestModel.Email,
                
                Status = "subscribed",
                
                MergeFields = new Dictionary<string, object>()
                {
                    ["NAME"] = contactRequestModel.Name,
                    ["PROJECT"] = contactRequestModel.Project,
                    ["PAGE"] = contactRequestModel.ContactPageAddress,
                },
                
                Interests = new Dictionary<string, object>()
                {
                    [dataConsentInterestId] = contactRequestModel.DataCollectionConsent
                }
            };

            await mailchimpService.Post(postMemberModel);
        }
    }
}