﻿using System.Threading.Tasks;
using BlazorAppHosted.Server.Services.MailchimpService.Models;

namespace BlazorAppHosted.Server.Services.MailchimpService
{
    public interface IMailchimpService
    {
        Task Post(PostMemberModel postMemberModel);
    }
}
