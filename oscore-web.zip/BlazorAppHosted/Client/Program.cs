using System;
using System.Net.Http;
using System.Threading.Tasks;
using BlazorAppHosted.Client.Services;
using Microsoft.AspNetCore.Components.WebAssembly.Hosting;
using Microsoft.Extensions.DependencyInjection;

namespace BlazorAppHosted.Client
{
    public class Program
    {
        public static async Task Main(string[] args)
        {
            var builder = WebAssemblyHostBuilder.CreateDefault(args);
            builder.RootComponents.Add<App>("app");

            builder.Services.AddSingleton(new HttpClient { BaseAddress = new Uri(builder.HostEnvironment.BaseAddress) });

            builder.Services.AddScoped<ISubmitContactRequestService, SubmitContactRequestService>();

            builder.Services.AddScoped<IPageTitleService, PageTitleService>();
            
            builder.Services.AddScoped<IContactPageContentService, ContactPageContentService>();
            
            await builder.Build().RunAsync();
        }
    }
}
