﻿using System;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;
using BlazorAppHosted.Shared;
using Microsoft.AspNetCore.Components;


namespace BlazorAppHosted.Client
{
    public class SubmitContactRequestService : ISubmitContactRequestService
    {
        private readonly HttpClient _httpClient;
        private readonly NavigationManager _navigationManager;

        public SubmitContactRequestService(HttpClient httpClient, NavigationManager navigationManager)
        {
            _httpClient = httpClient;
            _navigationManager = navigationManager;
        }

        public async Task<(bool Success, string ErrorMessage)> SubmitContactRequestAsync(
            ContactRequestModel contactRequestModel)
        {
            contactRequestModel.ContactPageAddress = _navigationManager.Uri;

            try
            {
                var response = await _httpClient.PostAsJsonAsync("/api/contacts", contactRequestModel);

                response.EnsureSuccessStatusCode();

                return (true, null);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);

                return (false, e.Message);
            }
        }
    }

    public interface ISubmitContactRequestService
    {
        Task<(bool Success, string ErrorMessage)> SubmitContactRequestAsync(ContactRequestModel contactRequestModel);
    }
}