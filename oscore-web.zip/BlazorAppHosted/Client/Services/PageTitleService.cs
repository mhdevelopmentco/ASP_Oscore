﻿using System;
using Microsoft.JSInterop;


namespace BlazorAppHosted.Client
{
    public class PageTitleService : IPageTitleService
    {
        private readonly IJSRuntime _jsRuntime;

        public PageTitleService(IJSRuntime jsRuntime)
        {
            _jsRuntime = jsRuntime;
        }

        public void SetTitle(string title)
        {
            Console.WriteLine("Blazor setting Title to {0}", title);

            _jsRuntime.InvokeVoidAsync($"setTitle", title);
        }
    }

    public interface IPageTitleService
    {
        void SetTitle(string title);
    }
}