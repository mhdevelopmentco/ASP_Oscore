﻿using System;
using Microsoft.AspNetCore.Components;

namespace BlazorAppHosted.Client.Services
{
    public class ContactPageContentService : IContactPageContentService
    {
        private const string DefaultSubHeaderText = "Using .Net Core, Microsoft Azure, Cosmos DB or Power BI in a live or upcoming project? Reach out to us below and a specialist will be in touch within 24 hours. You will also receive an email with contact details should you wish to get in touch immediately.";

        private readonly NavigationManager _navigationManager;

        public ContactPageContentService(NavigationManager navigationManager)
        {
            _navigationManager = navigationManager;
        }

        public string ResolveTitle(string topic)
        {
            return topic?.ToLower() switch
            {
                "azure-cosmos-db" =>
                "Contact | Oscore | Azure Cosmos DB Specialists",
                _ => "Contact | Oscore | .Net Core Specialists",
            };
        }

        public string ResolveSubHeaderText(string topic)
        {
            return topic?.ToLower() switch
            {
                "azure-cosmos-db" =>
                "Using Azure Cosmos DB in a live or upcoming project? Reach out to us below and a specialist will be in touch within 24 hours. You will also receive an email with contact details should you wish to get in touch immediately.",
                _ => DefaultSubHeaderText
            };
        }

        public bool ResolveHeaderVisibility()
        {
            return !_navigationManager.Uri.Contains("learn-more", StringComparison.OrdinalIgnoreCase);
        }
    }

    public interface IContactPageContentService
    {
        string ResolveTitle(string topic);
        
        string ResolveSubHeaderText(string topic);

        bool ResolveHeaderVisibility();
    }
}