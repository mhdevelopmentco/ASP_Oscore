window.$ = jQuery;

// global App class declaration
function App() {
	this.init = function () {
		// call all default methods
		this.initFaviconSwitcher();
		this.initNotificationModal();
		this.initCookieNotification();
		this.initAnimationOnce();
		this.initPopover();
		this.initLightMode();
		this.menuDropdownLinkHandler();
	};

	this.initFaviconSwitcher = function () {
		// favicon changing on window/tab focus/blur
		document.head = document.head || document.getElementsByTagName('head')[0];

		// switcher function
		function changeFavicon(src) {
			var link = document.createElement('link'),
				oldLink = document.getElementById('dynamic-favicon');
			link.id = 'dynamic-favicon';
			link.rel = 'shortcut icon';
			link.href = src;
			if (oldLink) {
				document.head.removeChild(oldLink);
			}
			document.head.appendChild(link);
		}

		// event handlers
		window.onblur = function () {
			changeFavicon("./oscore_favicon_8.png");
		};
		window.onfocus = function () {
			changeFavicon("./oscore_favicon_4.png");
		};
	};

	this.initNotificationModal = function () {
		// information modal initialization (shows once)
		if (!localStorage.getItem('popupShown')) {
			$('.modal').modal('show');
			localStorage.setItem('popupShown', 'true');
		}
	};

	this.initCookieNotification = function () {
		// cookie alert initialization (cookieconsent plugin initialization)
		window.cookieconsent.initialise({
			container: document.getElementById("content"),
			palette: {
				popup: {background: "#fff"},
			},
			revokable: true,
			law: {
				regionalLaw: false,
			},
			elements: {
				dismiss: '<a aria-label="allow cookies" tabindex="0" class="cc-btn cc-allow btn btn-sm circle border-thick btn-bordered color-secondary font-size-18">Got it!</a>',
			},
			location: true,
		});
	};

	this.initAnimationOnce = function () {
		function getCurrentPage() {
			return window.location.pathname;
		}

		function getVisitedPages() {
			// returns urls array of visited pages or empty array if first time visited
			return localStorage.getItem('animationShown') ? JSON.parse(localStorage.getItem('animationShown')).pages : [];
		}

		function setVisitedPage() {
			// add current url to array of visited pages if not yet in array
			if (isPageVisited(getCurrentPage())) return;
			let newPages = getVisitedPages();
			newPages.push(getCurrentPage());
			localStorage.setItem('animationShown', JSON.stringify({pages: newPages}));
		}

		function isPageVisited(page) {
			// returns true if page is already visited and false if not
			return (getVisitedPages() !== [] && Object.values(getVisitedPages()).indexOf(page) > -1)
		}

		// shows hero section animation once for each page
		if (isPageVisited(getCurrentPage())) {
			$('.remove-double-animations').each(function () {
				$(this).data('ca-options', '');
			});
		} else {
			setVisitedPage();
		}
	};

	this.initPopover = function () {
		// popover initialization
		// $('[data-toggle="popover"]').popover();
	};

	this.initLightMode = function () {
		let body = document.querySelector('body');
		const toggle = document.querySelector('.mode-switcher');

		if (!toggle) return;

		toggle.checked = localStorage.getItem('modeState') === 'true';

		toggle.addEventListener('change', function () {
			localStorage.setItem('modeState', toggle.checked);
			modeSwitch();
		});

		window.addEventListener('load', function () {
			if (localStorage.getItem('modeState') === 'true') {
				modeSwitch();
			}
		});

		function modeSwitch() {
			if (body.classList.contains('mode-light')) {
				body.classList.remove('mode-light');
				body.classList.add('mode-dark');
			} else {
				body.classList.remove('mode-dark');
				body.classList.add('mode-light');
			}
		}
	}

	this.menuDropdownLinkHandler = function () {
		let links = document.querySelectorAll('.mainbar [data-toggle="dropdown"]');

		Array.prototype.forEach.call(links, function (el) {
			el.addEventListener('click', function (e) {
				window.location = e.currentTarget.href
			})
		})
	}
}

// Call app init method when document is ready
$(document).ready(function () {
	window.app = new App();
	app.init();
});
