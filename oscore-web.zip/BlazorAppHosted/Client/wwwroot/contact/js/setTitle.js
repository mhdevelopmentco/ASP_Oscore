﻿// https://dev.to/supachris28/changing-the-page-title-in-blazor-client-side-880
// used in PageTitle.razor
window.setTitle = (title) => {
    console.log("Setting title", title);
    document.title = title;
}
