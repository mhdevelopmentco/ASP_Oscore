﻿function handleAnchorClick(e) {
    e.preventDefault();

    var href = this.getAttribute("href");

    var hrefAnchor = this.getAttribute("hrefAnchor");

    href = hrefAnchor || href;

    console.log(href);
    
    window.location.assign(href);
}
